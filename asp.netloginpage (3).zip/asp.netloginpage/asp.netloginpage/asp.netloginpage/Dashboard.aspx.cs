﻿using System;
using System.Data;
using System.IO;
using Newtonsoft.Json.Linq;

namespace asp.netloginpage
{
    public partial class Dashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            bool match=false;
            String FilePath;
            FilePath = Server.MapPath(@"\convertcsv.json");
            string username = Session["UserName"].ToString();
            DataTable dataTablesummary = new DataTable();
            using (StreamReader file = File.OpenText(FilePath))
                 
            {

                string json = file.ReadToEnd();
                JObject jObject = JObject.Parse(json);
                JArray signInNames = (JArray)jObject.SelectToken("users");

                int count = 0;

                foreach (JToken signInName in signInNames)
                {
                    string CustomerNumber = (string)signInName.SelectToken("customerNumber");
                    string CardNumber = (string)signInName.SelectToken("cardNumber");
                    string ProductName = (string)signInName.SelectToken("accounts[0].productName");
                    string offers = (string)signInName.SelectToken("offers");



                    if (CustomerNumber == username)
                    {
                        match = true;
                        string Names = (string)signInName.SelectToken("names");
                        lblname.Text = "Welcome" + " " + Names;
                        count = count + 1;
                        if (count == 1)
                        {
                            dataTablesummary.Columns.Add("Customer Number", typeof(string));
                            dataTablesummary.Columns.Add("CardNumber", typeof(string));
                            dataTablesummary.Columns.Add("ProductName", typeof(string));
                            dataTablesummary.Columns.Add("Offers", typeof(string));
                            dataTablesummary.Rows.Add(CustomerNumber, CardNumber, ProductName, offers);


                        }
                        else
                        {

                            dataTablesummary.Rows.Add(CustomerNumber, CardNumber, ProductName, offers);

                        }


                    }

                }
                if (match == false)
                {
                    lblname.Text = "User Id not exist";

                }
            }
            GridView1.DataSource = dataTablesummary;
            GridView1.DataBind();
        }        
        
    }
}