﻿using System;

namespace asp.netloginpage
{
    
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblErrorMessage.Visible = false;
            
        }

        public void btnLogin_Click(object sender, EventArgs e)
        {
            Session["UserName"] = txtUserName.Text;
            if (txtPassword.Text == "Admin")
            {
                Response.Redirect("DashBoard.aspx");

            }

            else
            {
                lblErrorMessage.Text = "Incorrect credential";
                lblErrorMessage.Visible = true;

            }
            

        }

        protected void txtUserName_TextChanged(object sender, EventArgs e)
        {

        }
    


    }
}